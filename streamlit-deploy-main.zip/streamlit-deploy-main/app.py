import streamlit as st

st.set_page_config(
    page_title="AWS",
    page_icon="👋",
    layout="wide"
)

st.header("Hi, welcome!")
st.subheader("This is your Amazon Web Services (AWS) Streamlit deployment!", divider="rainbow")
